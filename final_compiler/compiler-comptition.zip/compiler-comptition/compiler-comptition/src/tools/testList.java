package tools;

public class testList {

    public static void main(String[] args) {
        MyList<Student> students = new MyList<>();
        Student student1 = new Student(1, "a");
        Student student2 = new Student(2, "b");
        Student student3 = new Student(3, "c");
        Student student4 = new Student(4, "d");

        students.insertAtTail(student1);
        students.insertAtTail(student2);
        students.insertAtTail(student3);
        students.insertAtTail(student4);

        for (Student student : students) {
            if (student.id < 5) {
                Student student5 = new Student(5, "e");
                student.insertAfter(student5);
            }
            System.out.println(student.id);
        }
    }

    public static class Student extends MyListNode {
        public int id;
        public String name;

        public Student(int id, String name) {
            super();
            this.id = id;
            this.name = name;
        }
    }

}
