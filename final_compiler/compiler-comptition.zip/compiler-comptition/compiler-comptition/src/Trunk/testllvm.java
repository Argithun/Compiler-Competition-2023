package Trunk;

import arm.armDS.ArmModule;
import arm.armDS.ArmTools;
import arm.regallocator.FloatRegAllocator;
import arm.regallocator.MaintainStack;
import arm.regallocator.RegAllocator;
import midend.*;
import midend.analysis.CFGBuilder;
import midend.analysis.LoopAnalysis;
import midend.analysis.LoopInductionVariableGet;
import mir.MyModule;
import tools.AllocaPre;

import java.util.Scanner;

public class testllvm {
    public static void main(String[] args) throws Exception {

        Scanner scanner = new Scanner(System.in);
        String path = scanner.nextLine();
        MyModule myModule = MyIO.genMyModel(path);

        CFGBuilder.analyseCFG(myModule);
        AllocaPre.allocaPre(myModule);
        CFGBuilder.analyseCFG(myModule);

        GlobalValueLocalize globalValueLocalize = new GlobalValueLocalize(myModule.globalValues);
        globalValueLocalize.runLocalization(myModule.globalValues);

        UselessRetValEmit uselessRetValEmit = new UselessRetValEmit(myModule);
        uselessRetValEmit.runUselessRetValEmit();

        Mem2Reg.run(myModule);

        FuncInline funcInline = new FuncInline(myModule);
        funcInline.run();

        SimpleDCE simpleDCE = new SimpleDCE(myModule);
        simpleDCE.run();

        UselessStoreEmit uselessStoreEmit = new UselessStoreEmit(myModule);
        uselessStoreEmit.run();

        DeadCodeElimination deadCodeElimination = new DeadCodeElimination(myModule);
        deadCodeElimination.run();

        InstrCombine instrCombine = new InstrCombine(myModule);
        instrCombine.runInstrCombine();

        GVN gvn = new GVN(myModule);
        gvn.runGVN();

        GCM gcm = new GCM(myModule);
        gcm.run();

        CFGBuilder.analyseCFG(myModule);
        AllocaPre.allocaPre(myModule);
        CFGBuilder.analyseCFG(myModule);

        LoopAnalysis.runLoopAnalysis(myModule);
        LoopUselessDel loopUselessDel = new LoopUselessDel(myModule);
        loopUselessDel.runLoopUselessDel();

        LoopAnalysis.runLoopAnalysis(myModule);
        LoopInvariantCodeMotion loopInvariantCodeMotion = new LoopInvariantCodeMotion(myModule);
        loopInvariantCodeMotion.runLoopCodeMotion();

        LoopAnalysis.runLoopAnalysis(myModule);
        LoopInductionVariableGet loopInductionVariableGet1 = new LoopInductionVariableGet(myModule.funcs);
        loopInductionVariableGet1.getLoopInductionVariable();
        LoopFold loopFold = new LoopFold(myModule);
        loopFold.runLoopFold();

//        LoopAnalysis.runLoopAnalysis(myModule);
//        LoopInductionVariableGet loopInductionVariableGet2 = new LoopInductionVariableGet(myModule.funcs);
//        loopInductionVariableGet2.getLoopInductionVariable();
//        LoopUnrolling loopUnrolling = new LoopUnrolling(myModule);
//        loopUnrolling.runLoopUnroll(myModule);

//        BranchOpt branchOpt = new BranchOpt(myModule);
//        branchOpt.run();
//
//        GVN gvn1 = new GVN(myModule);
//        gvn1.runGVN();
//
//        SimpleDCE simpleDCE1 = new SimpleDCE(myModule);
//        simpleDCE1.run();
//
//        DeadCodeElimination deadCodeElimination1 = new DeadCodeElimination(myModule);
//        deadCodeElimination1.run();
//
//        GCM gcm1 = new GCM(myModule);
//        gcm1.run();
//
//        InstrCombine instrCombine1 = new InstrCombine(myModule);
//        instrCombine1.runInstrCombine();
//
        AddFold addFold = new AddFold(myModule);
        addFold.run();

        DivMulMod divMulMod = new DivMulMod(myModule);
        divMulMod.run();

        BranchOpt branchOpt1 = new BranchOpt(myModule);
        branchOpt1.run();

        BlockOrderAdjust.runBlockOrderAdjust(myModule);

        RemovePhi removePhi = new RemovePhi(myModule);
        removePhi.run();

        //MyIO.outLlvm(myModule, "main.c");

        ArmTools armTools = new ArmTools();
        armTools.parserIrModel(myModule);
        ArmModule armModule = armTools.getArmModule();

        FloatRegAllocator floatRegAllocator = new FloatRegAllocator(armTools);
        RegAllocator regAllocator = new RegAllocator(armTools);
        MaintainStack maintainStack = new MaintainStack(armTools);
        System.out.println(armTools.getArmFromSelf());

    }
}
