package frontend.ast;

import java.io.IOException;

public class testAst {
    public static void main(String[] args) throws IOException {
        Builder builder = new Builder();
        Node ast = builder.buildAst("main.c");
    }
}
