// Generated from C:/CompileComp/compiler-comptition/compiler-comptition/src/frontend/src/main/java\Sysy.g4 by ANTLR 4.12.0
package frontend.lexerparser;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SysyParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SysyVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParse(SysyParser.ParseContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(SysyParser.NumberContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBtype(SysyParser.BtypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl(SysyParser.DeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef(SysyParser.DefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitval(SysyParser.InitvalContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#initarray}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitarray(SysyParser.InitarrayContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(SysyParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStmt(SysyParser.StmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(SysyParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#expstmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpstmt(SysyParser.ExpstmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#ifstmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfstmt(SysyParser.IfstmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#whilestmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhilestmt(SysyParser.WhilestmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#breakstmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreakstmt(SysyParser.BreakstmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#continuestmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinuestmt(SysyParser.ContinuestmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#returnstmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnstmt(SysyParser.ReturnstmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(SysyParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond(SysyParser.CondContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLval(SysyParser.LvalContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funccall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunccall(SysyParser.FunccallContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#binaryexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryexp(SysyParser.BinaryexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp(SysyParser.OpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLandexp(SysyParser.LandexpContext ctx);
}