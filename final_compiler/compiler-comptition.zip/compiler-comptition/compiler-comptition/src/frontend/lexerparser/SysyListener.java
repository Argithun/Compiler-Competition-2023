// Generated from C:/CompileComp/compiler-comptition/compiler-comptition/src/frontend/src/main/java\Sysy.g4 by ANTLR 4.12.0
package frontend.lexerparser;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SysyParser}.
 */
public interface SysyListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 */
	void enterParse(SysyParser.ParseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 */
	void exitParse(SysyParser.ParseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 */
	void enterCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 */
	void exitCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(SysyParser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(SysyParser.NumberContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 */
	void enterIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 */
	void exitIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 */
	void enterFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 */
	void exitFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 */
	void enterBtype(SysyParser.BtypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 */
	void exitBtype(SysyParser.BtypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 */
	void enterDecl(SysyParser.DeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 */
	void exitDecl(SysyParser.DeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#def}.
	 * @param ctx the parse tree
	 */
	void enterDef(SysyParser.DefContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#def}.
	 * @param ctx the parse tree
	 */
	void exitDef(SysyParser.DefContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 */
	void enterInitval(SysyParser.InitvalContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 */
	void exitInitval(SysyParser.InitvalContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#initarray}.
	 * @param ctx the parse tree
	 */
	void enterInitarray(SysyParser.InitarrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#initarray}.
	 * @param ctx the parse tree
	 */
	void exitInitarray(SysyParser.InitarrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void enterFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void exitFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 */
	void enterFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 */
	void exitFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 */
	void enterFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 */
	void exitFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 */
	void enterFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 */
	void exitFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(SysyParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(SysyParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 */
	void enterBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 */
	void exitBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(SysyParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(SysyParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(SysyParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(SysyParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#expstmt}.
	 * @param ctx the parse tree
	 */
	void enterExpstmt(SysyParser.ExpstmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#expstmt}.
	 * @param ctx the parse tree
	 */
	void exitExpstmt(SysyParser.ExpstmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#ifstmt}.
	 * @param ctx the parse tree
	 */
	void enterIfstmt(SysyParser.IfstmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#ifstmt}.
	 * @param ctx the parse tree
	 */
	void exitIfstmt(SysyParser.IfstmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#whilestmt}.
	 * @param ctx the parse tree
	 */
	void enterWhilestmt(SysyParser.WhilestmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#whilestmt}.
	 * @param ctx the parse tree
	 */
	void exitWhilestmt(SysyParser.WhilestmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#breakstmt}.
	 * @param ctx the parse tree
	 */
	void enterBreakstmt(SysyParser.BreakstmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#breakstmt}.
	 * @param ctx the parse tree
	 */
	void exitBreakstmt(SysyParser.BreakstmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#continuestmt}.
	 * @param ctx the parse tree
	 */
	void enterContinuestmt(SysyParser.ContinuestmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#continuestmt}.
	 * @param ctx the parse tree
	 */
	void exitContinuestmt(SysyParser.ContinuestmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#returnstmt}.
	 * @param ctx the parse tree
	 */
	void enterReturnstmt(SysyParser.ReturnstmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#returnstmt}.
	 * @param ctx the parse tree
	 */
	void exitReturnstmt(SysyParser.ReturnstmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(SysyParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(SysyParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCond(SysyParser.CondContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCond(SysyParser.CondContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 */
	void enterLval(SysyParser.LvalContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 */
	void exitLval(SysyParser.LvalContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 */
	void enterPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 */
	void exitPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funccall}.
	 * @param ctx the parse tree
	 */
	void enterFunccall(SysyParser.FunccallContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funccall}.
	 * @param ctx the parse tree
	 */
	void exitFunccall(SysyParser.FunccallContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 */
	void enterUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 */
	void exitUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 */
	void enterFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 */
	void exitFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#binaryexp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryexp(SysyParser.BinaryexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#binaryexp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryexp(SysyParser.BinaryexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#op}.
	 * @param ctx the parse tree
	 */
	void enterOp(SysyParser.OpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#op}.
	 * @param ctx the parse tree
	 */
	void exitOp(SysyParser.OpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 */
	void enterLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 */
	void exitLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 */
	void enterLandexp(SysyParser.LandexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 */
	void exitLandexp(SysyParser.LandexpContext ctx);
}