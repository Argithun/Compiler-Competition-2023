package arm.arminstructions;

import arm.armDS.ArmBlock;
import arm.armDS.ArmInstr;
import arm.armDS.ArmTools;
import arm.armoperands.ArmOperand;
import arm.armoperands.VirtualReg;

public class ArmVLoad extends ArmInstr {
    private ArmOperand dst; // 目标
    private ArmOperand addr; // 右值
    private ArmOperand offset; // load 指令是有偏移的

    @Override
    public String toString() {
        ArmTools.addOff(1);
        return "\tvldr" + getCond() + "\t" + dst +
                ",\t[" + addr + ",\t" + offset + getShift() + "]\n";
    }

    public ArmVLoad(ArmBlock ab, ArmOperand dst, ArmOperand addr, ArmOperand offset) {
        super(ab);
        setDst(dst);
        setAddr(addr);
        setOffset(offset);
        ab.addArmInstrToEnd(this);

        dst.setIsDst(true);
    }

    public ArmOperand getDst() {
        return dst;
    }

    public ArmOperand getAddr() {
        return addr;
    }

    public ArmOperand getOffset() {
        return offset;
    }

    public void setDst(ArmOperand dst) {
        updateReg(this.dst, dst, false);
        this.dst = dst;
        if (dst instanceof VirtualReg) {
            ((VirtualReg) dst).setDefInstr(this);
        }
    }

    public void setAddr(ArmOperand addr) {
        updateReg(this.addr, addr, true);
        this.addr = addr;
    }

    public void setOffset(ArmOperand offset) {
        updateReg(this.offset, offset, true);
        this.offset = offset;
    }
}
