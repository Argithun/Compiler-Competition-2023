package arm.armoperands;

public class Reg extends ArmOperand {
    public Reg(OpType ty) {
        super(ty);
    }
}
