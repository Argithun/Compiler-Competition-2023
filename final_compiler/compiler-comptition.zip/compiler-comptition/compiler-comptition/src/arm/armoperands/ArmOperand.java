package arm.armoperands;

import java.util.Objects;

public class ArmOperand {
    // arm 指令的操作数, 可以是以下类型: 虚拟寄存器/物理寄存器/操作数
    public enum OpType {
        virtual,
        phy,
        floatPhy,
        imme,
        floatImme;
    }

    private boolean isDst; // 是否在指令中是被赋值的那个

    public boolean isDst() {
        return isDst;
    }

    private boolean needColor = false;

    public boolean isPreColored() {
        return false;
    }

    public boolean needColor() {
        return needColor;
    }

    public void setNeedColor(boolean needColor) {
        this.needColor = needColor;
    }

    private boolean isAllocated = false; // 被分配, 在寄存器分配之前, new 出来的对象都是未被分配

    public boolean isAllocated() {
        return isAllocated;
    }

    public void setAllocated(boolean allocated) {
        isAllocated = allocated;
    }

    public boolean isReg() {
        return this instanceof Reg;
    }

    public void setIsDst(boolean isDst) {
        this.isDst = isDst;
    }

    public boolean isFloat() {
        return this.type == OpType.floatImme || this.type == OpType.floatPhy ||
                (this.type == OpType.virtual && ((VirtualReg) this).isFloat());
    }

    public boolean isInt() {
        return this.type == OpType.imme || this.type == OpType.phy ||
                (this.type == OpType.virtual && ((VirtualReg) this).isInt());
    }

    private OpType type;

    public OpType getType() {
        return type;
    }

    public ArmOperand(OpType ty) {
        this.type = ty;
        this.isDst = false;
        this.needColor = false;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ArmOperand)) {
            return false;
        }
        if (((ArmOperand) obj).getType() != this.type) {
            return false;
        }
        if (this.type == OpType.imme) {
            return ((Imme) this).getImme() == ((Imme) obj).getImme();
        }
        if (this.type == OpType.floatImme) {
            return ((FloatImme) this).getImme() == ((FloatImme) obj).getImme();
        }
        return this.equals(obj);
    }
}
