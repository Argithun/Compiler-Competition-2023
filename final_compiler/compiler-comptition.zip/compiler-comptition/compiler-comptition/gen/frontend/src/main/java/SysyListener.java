// Generated from C:/CompileComp/compiler-comptition/compiler-comptition/src/frontend/src/main/java\Sysy.g4 by ANTLR 4.12.0
package frontend.src.main.java;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SysyParser}.
 */
public interface SysyListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 */
	void enterParse(SysyParser.ParseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 */
	void exitParse(SysyParser.ParseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 */
	void enterCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 */
	void exitCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(SysyParser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(SysyParser.NumberContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 */
	void enterIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 */
	void exitIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 */
	void enterFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 */
	void exitFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 */
	void enterDecl(SysyParser.DeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 */
	void exitDecl(SysyParser.DeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#constdecl}.
	 * @param ctx the parse tree
	 */
	void enterConstdecl(SysyParser.ConstdeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#constdecl}.
	 * @param ctx the parse tree
	 */
	void exitConstdecl(SysyParser.ConstdeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 */
	void enterBtype(SysyParser.BtypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 */
	void exitBtype(SysyParser.BtypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#constdef}.
	 * @param ctx the parse tree
	 */
	void enterConstdef(SysyParser.ConstdefContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#constdef}.
	 * @param ctx the parse tree
	 */
	void exitConstdef(SysyParser.ConstdefContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#constinitval}.
	 * @param ctx the parse tree
	 */
	void enterConstinitval(SysyParser.ConstinitvalContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#constinitval}.
	 * @param ctx the parse tree
	 */
	void exitConstinitval(SysyParser.ConstinitvalContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#vardecl}.
	 * @param ctx the parse tree
	 */
	void enterVardecl(SysyParser.VardeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#vardecl}.
	 * @param ctx the parse tree
	 */
	void exitVardecl(SysyParser.VardeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#vardef}.
	 * @param ctx the parse tree
	 */
	void enterVardef(SysyParser.VardefContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#vardef}.
	 * @param ctx the parse tree
	 */
	void exitVardef(SysyParser.VardefContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 */
	void enterInitval(SysyParser.InitvalContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 */
	void exitInitval(SysyParser.InitvalContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void enterFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 */
	void exitFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 */
	void enterFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 */
	void exitFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 */
	void enterFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 */
	void exitFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 */
	void enterFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 */
	void exitFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(SysyParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(SysyParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 */
	void enterBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 */
	void exitBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(SysyParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(SysyParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(SysyParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(SysyParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCond(SysyParser.CondContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCond(SysyParser.CondContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 */
	void enterLval(SysyParser.LvalContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 */
	void exitLval(SysyParser.LvalContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 */
	void enterPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 */
	void exitPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 */
	void enterUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 */
	void exitUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 */
	void enterFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 */
	void exitFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#mulexp}.
	 * @param ctx the parse tree
	 */
	void enterMulexp(SysyParser.MulexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#mulexp}.
	 * @param ctx the parse tree
	 */
	void exitMulexp(SysyParser.MulexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#addexp}.
	 * @param ctx the parse tree
	 */
	void enterAddexp(SysyParser.AddexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#addexp}.
	 * @param ctx the parse tree
	 */
	void exitAddexp(SysyParser.AddexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#relexp}.
	 * @param ctx the parse tree
	 */
	void enterRelexp(SysyParser.RelexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#relexp}.
	 * @param ctx the parse tree
	 */
	void exitRelexp(SysyParser.RelexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#eqexp}.
	 * @param ctx the parse tree
	 */
	void enterEqexp(SysyParser.EqexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#eqexp}.
	 * @param ctx the parse tree
	 */
	void exitEqexp(SysyParser.EqexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 */
	void enterLandexp(SysyParser.LandexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 */
	void exitLandexp(SysyParser.LandexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 */
	void enterLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 */
	void exitLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Enter a parse tree produced by {@link SysyParser#constexp}.
	 * @param ctx the parse tree
	 */
	void enterConstexp(SysyParser.ConstexpContext ctx);
	/**
	 * Exit a parse tree produced by {@link SysyParser#constexp}.
	 * @param ctx the parse tree
	 */
	void exitConstexp(SysyParser.ConstexpContext ctx);
}