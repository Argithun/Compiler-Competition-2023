// Generated from C:/CompileComp/compiler-comptition/compiler-comptition/src/frontend/src/main/java\Sysy.g4 by ANTLR 4.12.0
package frontend.src.main.java;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SysyParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SysyVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SysyParser#parse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParse(SysyParser.ParseContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#compunit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompunit(SysyParser.CompunitContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(SysyParser.NumberContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#intconst}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntconst(SysyParser.IntconstContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#floatconst}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatconst(SysyParser.FloatconstContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl(SysyParser.DeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#constdecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstdecl(SysyParser.ConstdeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#btype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBtype(SysyParser.BtypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#constdef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstdef(SysyParser.ConstdefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#constinitval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstinitval(SysyParser.ConstinitvalContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#vardecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVardecl(SysyParser.VardeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#vardef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVardef(SysyParser.VardefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#initval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitval(SysyParser.InitvalContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcdef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncdef(SysyParser.FuncdefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#functype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctype(SysyParser.FunctypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcfparam}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncfparam(SysyParser.FuncfparamContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcfparams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncfparams(SysyParser.FuncfparamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(SysyParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#blockitem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockitem(SysyParser.BlockitemContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStmt(SysyParser.StmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(SysyParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond(SysyParser.CondContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#lval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLval(SysyParser.LvalContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#primaryexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryexp(SysyParser.PrimaryexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#unaryexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryexp(SysyParser.UnaryexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#unaryop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryop(SysyParser.UnaryopContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#funcrparams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncrparams(SysyParser.FuncrparamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#mulexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulexp(SysyParser.MulexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#addexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddexp(SysyParser.AddexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#relexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelexp(SysyParser.RelexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#eqexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqexp(SysyParser.EqexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#landexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLandexp(SysyParser.LandexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#lorexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLorexp(SysyParser.LorexpContext ctx);
	/**
	 * Visit a parse tree produced by {@link SysyParser#constexp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstexp(SysyParser.ConstexpContext ctx);
}